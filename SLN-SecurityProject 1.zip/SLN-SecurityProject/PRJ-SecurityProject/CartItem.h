#pragma once
#include <string>

class CartItem {
	std::string peoductName;
	int productIdNum;
	int quantity;
	float price;
};