#pragma once
#include "CartItem.h"

class User {
protected:
	std::string userID;
	std::string password;
	std::string accessLevel;
	std::string phoneNum; //changed from long long int to string
public:
	
	//virtual User login(std::string, std::string);
	//virtual float taxCalc();
	//virtual void logout();
	//virtual CartItem checkStatus();
	//virtual std::string returnAccountInfo(User);
};
