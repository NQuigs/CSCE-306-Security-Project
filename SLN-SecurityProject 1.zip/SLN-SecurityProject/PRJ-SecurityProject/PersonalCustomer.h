#pragma once
#include "User.h"
#include "Customer.h"

class PersonalCustomer :public Customer {


};